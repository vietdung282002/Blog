﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'ko', {
	anchor: '책갈피',
	hiddenfield: '숨은 입력 칸',
	iframe: '아이프레임',
	unknown: '알 수 없는 객체'
} );
